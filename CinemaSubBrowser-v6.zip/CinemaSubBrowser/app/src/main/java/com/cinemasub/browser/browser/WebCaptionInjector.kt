package com.cinemasub.browser.browser

import android.webkit.JavascriptInterface

class CaptionJsBridge(
    private val onCaptionCue: (String) -> Unit
) {
    @JavascriptInterface
    fun onCaption(text: String?) {
        onCaptionCue(text?.trim().orEmpty())
    }
}

object WebCaptionInjector {

    const val BRIDGE_NAME = "CinemaSubBridge"

    fun setEnabledScript(enabled: Boolean): String =
        "if (window.__cinemaSubSetEnabled) { window.__cinemaSubSetEnabled($enabled); }"

    val INJECT_SCRIPT: String = """
        (function() {
            if (window.__cinemaSubInstalled) return;
            window.__cinemaSubInstalled = true;
            window.__cinemaSubEnabled = false;

            var lastSentText = "";
            var trackedVideos = new WeakSet();
            var trackedTextTracks = new WeakSet();

            function cleanText(raw) {
                if (!raw) return "";
                return raw
                    .replace(/<[^>]*>/g, " ")
                    .replace(/\s+/g, " ")
                    .trim();
            }

            function emitCaption(text) {
                if (!window.__cinemaSubEnabled) return;
                var cleaned = cleanText(text);
                if (cleaned === lastSentText) return;
                lastSentText = cleaned;
                try {
                    if (window.CinemaSubBridge && window.CinemaSubBridge.onCaption) {
                        window.CinemaSubBridge.onCaption(cleaned);
                    }
                } catch (e) {}
            }

            function toggleHideOriginalCss(hide) {
                var styleId = "cinemasub-hide-orig-captions";
                var existing = document.getElementById(styleId);
                if (hide) {
                    if (!existing) {
                        var style = document.createElement("style");
                        style.id = styleId;
                        style.textContent = [
                            ".ytp-caption-window-container,",
                            ".caption-window,",
                            ".vjs-text-track-display,",
                            ".jw-captions,",
                            ".plyr__captions,",
                            ".vp-captions,",
                            ".shaka-text-container,",
                            ".bmpui-ui-subtitle-label {",
                            "  opacity: 0 !important;",
                            "  pointer-events: none !important;",
                            "}"
                        ].join("\n");
                        (document.head || document.documentElement).appendChild(style);
                    }
                } else if (existing) {
                    existing.remove();
                }
            }

            function tryEnableSiteCaptions() {
                if (!window.__cinemaSubEnabled) return;
                try {
                    var ytBtn = document.querySelector(".ytp-subtitles-button");
                    if (ytBtn && ytBtn.getAttribute("aria-pressed") === "false") {
                        ytBtn.click();
                    }
                } catch (e) {}
            }

            function bindTrack(track) {
                if (!track || trackedTextTracks.has(track)) return;
                trackedTextTracks.add(track);
                track.addEventListener("cuechange", function() {
                    if (!window.__cinemaSubEnabled) return;
                    var cues = track.activeCues;
                    if (!cues || cues.length === 0) {
                        emitCaption("");
                        return;
                    }
                    var parts = [];
                    for (var i = 0; i < cues.length; i++) {
                        if (cues[i] && cues[i].text) {
                            parts.push(cues[i].text);
                        }
                    }
                    emitCaption(parts.join(" "));
                });
            }

            function attachVideoTracks(video) {
                if (!video || !video.textTracks) return;
                var tracks = video.textTracks;
                var chosenTrack = null;

                for (var i = 0; i < tracks.length; i++) {
                    var t = tracks[i];
                    if (t.kind === "subtitles" || t.kind === "captions") {
                        bindTrack(t);
                        if (window.__cinemaSubEnabled) {
                            if (t.mode === "showing") {
                                t.mode = "hidden";
                                chosenTrack = t;
                            } else if (!chosenTrack && t.language && t.language.toLowerCase().indexOf("en") === 0) {
                                chosenTrack = t;
                            } else if (!chosenTrack) {
                                chosenTrack = t;
                            }
                        }
                    }
                }

                if (window.__cinemaSubEnabled && chosenTrack && chosenTrack.mode === "disabled") {
                    chosenTrack.mode = "hidden";
                }

                if (!trackedVideos.has(video)) {
                    trackedVideos.add(video);
                    try {
                        tracks.addEventListener("addtrack", function(ev) {
                            if (ev && ev.track) {
                                bindTrack(ev.track);
                                if (window.__cinemaSubEnabled && ev.track.mode === "disabled") {
                                    ev.track.mode = "hidden";
                                }
                            }
                        });
                    } catch (e) {}
                }
            }

            function scanAllVideos() {
                var videos = document.querySelectorAll("video");
                for (var i = 0; i < videos.length; i++) {
                    attachVideoTracks(videos[i]);
                }
            }

            var domSelectors = [
                ".ytp-caption-segment",
                ".caption-visual-line",
                ".vjs-text-track-cue",
                ".jw-text-track-cue",
                ".plyr__caption",
                ".vp-captions span",
                ".shaka-text-container span",
                ".bmpui-ui-subtitle-label"
            ];

            function readDomCaptions() {
                if (!window.__cinemaSubEnabled) return;
                for (var s = 0; s < domSelectors.length; s++) {
                    var nodes = document.querySelectorAll(domSelectors[s]);
                    if (nodes && nodes.length > 0) {
                        var parts = [];
                        for (var j = 0; j < nodes.length; j++) {
                            var txt = (nodes[j].innerText || nodes[j].textContent || "").trim();
                            if (txt) parts.push(txt);
                        }
                        var combined = parts.join(" ").trim();
                        if (combined.length > 0 && combined.length <= 260) {
                            emitCaption(combined);
                            return;
                        }
                    }
                }
            }

            var domTimer = null;
            var observer = new MutationObserver(function() {
                if (!window.__cinemaSubEnabled) return;
                if (domTimer) return;
                domTimer = setTimeout(function() {
                    domTimer = null;
                    readDomCaptions();
                }, 40);
            });

            if (document.body) {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true,
                    characterData: true
                });
            }

            setInterval(function() {
                if (!window.__cinemaSubEnabled) return;
                scanAllVideos();
                readDomCaptions();
            }, 1200);

            window.__cinemaSubSetEnabled = function(enabled) {
                window.__cinemaSubEnabled = !!enabled;
                lastSentText = "";
                toggleHideOriginalCss(window.__cinemaSubEnabled);
                if (window.__cinemaSubEnabled) {
                    tryEnableSiteCaptions();
                    scanAllVideos();
                    readDomCaptions();
                }
            };
        })();
    """.trimIndent()
}
