package com.cinemasub.browser.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CinemaDarkColors = darkColorScheme(
    primary = Color(0xFFE50914),
    onPrimary = Color.White,
    secondary = Color(0xFFF5C518),
    background = Color(0xFF0E0E10),
    surface = Color(0xFF18181B),
    surfaceVariant = Color(0xFF27272A),
    onBackground = Color(0xFFF4F4F5),
    onSurface = Color(0xFFF4F4F5),
    onSurfaceVariant = Color(0xFFA1A1AA)
)

@Composable
fun CinemaSubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CinemaDarkColors,
        content = content
    )
}
