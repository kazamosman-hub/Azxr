package com.cinemasub.browser.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cinemasub.browser.browser.AdBlocker
import com.cinemasub.browser.browser.CaptionJsBridge
import com.cinemasub.browser.browser.WebCaptionInjector
import com.cinemasub.browser.model.SubtitleSourceMode
import com.cinemasub.browser.ui.components.BookmarksDialog
import com.cinemasub.browser.ui.components.NetflixSubtitleOverlay
import com.cinemasub.browser.ui.components.SubtitleSettingsSheet

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    onToggleSmartTranslation: () -> Unit,
    onToggleLiveAudioFallback: () -> Unit,
    onSystemFullscreenChanged: (Boolean) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val subtitleState by viewModel.subtitleState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    var showSettingsSheet by remember { mutableStateOf(false) }
    var showBookmarksDialog by remember { mutableStateOf(false) }

    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = true
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            }

            addJavascriptInterface(
                CaptionJsBridge { cueText -> viewModel.onWebCaptionReceived(cueText) },
                WebCaptionInjector.BRIDGE_NAME
            )

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    if (viewModel.uiState.value.adBlockerEnabled && AdBlocker.isAd(request?.url?.toString())) {
                        viewModel.incrementBlockedAds()
                        return AdBlocker.createEmptyResponse()
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    url?.let { viewModel.onPageStarted(it) }
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    url?.let {
                        viewModel.onPageFinished(
                            url = it,
                            canGoBack = view?.canGoBack() == true,
                            canGoForward = view?.canGoForward() == true
                        )
                    }
                    view?.evaluateJavascript(WebCaptionInjector.INJECT_SCRIPT, null)
                    view?.evaluateJavascript(
                        WebCaptionInjector.setEnabledScript(viewModel.uiState.value.webCaptionEnabled),
                        null
                    )
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    viewModel.onProgressChanged(newProgress)
                }

                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    viewModel.onFullscreenChanged(true)
                    onSystemFullscreenChanged(true)
                }

                override fun onHideCustomView() {
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    viewModel.onFullscreenChanged(false)
                    onSystemFullscreenChanged(false)
                }
            }
        }
    }

    LaunchedEffect(uiState.webCaptionEnabled) {
        webView.evaluateJavascript(WebCaptionInjector.INJECT_SCRIPT, null)
        webView.evaluateJavascript(
            WebCaptionInjector.setEnabledScript(uiState.webCaptionEnabled),
            null
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            webView.stopLoading()
            webView.removeJavascriptInterface(WebCaptionInjector.BRIDGE_NAME)
            webView.webChromeClient = null
            webView.destroy()
        }
    }

    BackHandler(enabled = customView != null || (!uiState.isHomeVisible && webView.canGoBack())) {
        when {
            customView != null -> {
                customViewCallback?.onCustomViewHidden()
                customView = null
                customViewCallback = null
                viewModel.onFullscreenChanged(false)
                onSystemFullscreenChanged(false)
            }
            webView.canGoBack() -> webView.goBack()
            else -> viewModel.goHome()
        }
    }

    fun loadInput(input: String) {
        val targetUrl = viewModel.resolveInputToUrl(input)
        viewModel.onNavigateTo(targetUrl)
        webView.loadUrl(targetUrl)
        focusManager.clearFocus()
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Scaffold(
            topBar = {
                if (!uiState.isFullscreenVideo) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface)
                            .statusBarsPadding()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .clip(RoundedCornerShape(21.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 14.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                BasicTextField(
                                    value = uiState.addressBarText,
                                    onValueChange = viewModel::onAddressBarChanged,
                                    singleLine = true,
                                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                    keyboardActions = KeyboardActions(onGo = { loadInput(uiState.addressBarText) }),
                                    modifier = Modifier.fillMaxWidth(),
                                    decorationBox = { inner ->
                                        if (uiState.addressBarText.isEmpty()) {
                                            Text("ابحث أو أدخل رابط الموقع...", color = Color.Gray, fontSize = 14.sp)
                                        }
                                        inner()
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(onClick = {
                                if (uiState.isLoading) webView.stopLoading() else webView.reload()
                            }) {
                                Icon(
                                    imageVector = if (uiState.isLoading) Icons.Default.Close else Icons.Default.Refresh,
                                    contentDescription = "تحديث"
                                )
                            }

                            IconButton(onClick = viewModel::toggleAdBlocker) {
                                BadgedBox(
                                    badge = {
                                        if (uiState.adBlockerEnabled && uiState.blockedAdsCount > 0) {
                                            Badge { Text("${uiState.blockedAdsCount}") }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = "مانع الإعلانات",
                                        tint = if (uiState.adBlockerEnabled) Color(0xFF22C55E) else Color.Gray
                                    )
                                }
                            }
                        }

                        if (uiState.isLoading) {
                            LinearProgressIndicator(
                                progress = { uiState.loadingProgress / 100f },
                                modifier = Modifier.fillMaxWidth().height(2.dp)
                            )
                        }
                    }
                }
            },
            bottomBar = {
                if (!uiState.isFullscreenVideo) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        NavigationBarItem(
                            selected = false,
                            onClick = { if (webView.canGoBack()) webView.goBack() },
                            icon = { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") },
                            enabled = uiState.canGoBack
                        )
                        NavigationBarItem(
                            selected = false,
                            onClick = { if (webView.canGoForward()) webView.goForward() },
                            icon = { Icon(Icons.AutoMirrored.Filled.ArrowForward, "تقدم") },
                            enabled = uiState.canGoForward
                        )
                        NavigationBarItem(
                            selected = uiState.isHomeVisible,
                            onClick = { viewModel.goHome() },
                            icon = { Icon(Icons.Default.Home, "الرئيسية") }
                        )
                        NavigationBarItem(
                            selected = false,
                            onClick = { showBookmarksDialog = true },
                            icon = { Icon(Icons.Default.Bookmarks, "المفضلة") }
                        )
                        NavigationBarItem(
                            selected = false,
                            onClick = { showSettingsSheet = true },
                            icon = { Icon(Icons.Default.Tune, "إعدادات الترجمة") }
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                AndroidView(
                    factory = { webView },
                    modifier = Modifier.fillMaxSize()
                )

                if (uiState.isHomeVisible) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "CinemaSub Browser",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "ترجمة فورية بالذكاء الاصطناعي وتزامن صفري",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(viewModel.quickLinks) { link ->
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .height(84.dp)
                                        .clickable { loadInput(link.url) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(14.dp)
                                                .clip(CircleShape)
                                                .background(link.accentColor)
                                        )
                                        Text(link.title, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        customView?.let { videoView ->
            AndroidView(
                factory = { ctx ->
                    FrameLayout(ctx).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        (videoView.parent as? ViewGroup)?.removeView(videoView)
                        addView(
                            videoView,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        NetflixSubtitleOverlay(
            subtitleState = subtitleState,
            styleConfig = uiState.subtitleStyle,
            onVerticalBiasChanged = viewModel::updateVerticalBias
        )

        AnimatedVisibility(
            visible = uiState.showFullscreenPrompt,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 20.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xDD18181B),
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("تفعيل الترجمة العربية الفورية؟", color = Color.White, fontSize = 13.sp)
                    Button(onClick = {
                        viewModel.dismissFullscreenPrompt()
                        onToggleSmartTranslation()
                    }) {
                        Text("تشغيل")
                    }
                    IconButton(onClick = viewModel::dismissFullscreenPrompt) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FloatingActionButton(
                onClick = onToggleSmartTranslation,
                containerColor = if (subtitleState.isLiveEnabled) {
                    MaterialTheme.colorScheme.primary
                } else {
                    Color(0xCC27272A)
                },
                contentColor = Color.White,
                modifier = Modifier.size(52.dp)
            ) {
                Icon(
                    imageVector = if (subtitleState.isLiveEnabled) Icons.Default.Subtitles else Icons.Default.Translate,
                    contentDescription = "ترجمة فورية من الموقع"
                )
            }

            AnimatedVisibility(
                visible = subtitleState.isLiveEnabled && !uiState.hasReceivedWebCaption ||
                    subtitleState.sourceMode == SubtitleSourceMode.LIVE_AUDIO
            ) {
                SmallFloatingActionButton(
                    onClick = onToggleLiveAudioFallback,
                    containerColor = if (subtitleState.sourceMode == SubtitleSourceMode.LIVE_AUDIO) {
                        Color(0xFF22C55E)
                    } else {
                        Color(0xDD18181B)
                    },
                    contentColor = Color.White
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "التقاط الصوت المباشر"
                    )
                }
            }
        }
    }

    if (showSettingsSheet) {
        SubtitleSettingsSheet(
            styleConfig = uiState.subtitleStyle,
            aiConfig = uiState.aiConfig,
            onEngineChange = { viewModel.updateTranslationEngine(context, it) },
            onGeminiKeyChange = { viewModel.updateGeminiApiKey(context, it) },
            onGroqKeyChange = { viewModel.updateGroqApiKey(context, it) },
            onFontSizeChange = viewModel::updateFontSize,
            onTextColorChange = viewModel::updateTextColor,
            onBgOpacityChange = viewModel::updateBgOpacity,
            onVerticalBiasChange = viewModel::updateVerticalBias,
            onDismiss = { showSettingsSheet = false }
        )
    }

    if (showBookmarksDialog) {
        BookmarksDialog(
            bookmarks = uiState.bookmarks,
            currentUrl = uiState.currentUrl,
            onAddCurrent = { viewModel.addBookmark(webView.title ?: uiState.currentUrl, uiState.currentUrl) },
            onSelect = { url ->
                showBookmarksDialog = false
                loadInput(url)
            },
            onDelete = viewModel::removeBookmark,
            onDismiss = { showBookmarksDialog = false }
        )
    }
}
