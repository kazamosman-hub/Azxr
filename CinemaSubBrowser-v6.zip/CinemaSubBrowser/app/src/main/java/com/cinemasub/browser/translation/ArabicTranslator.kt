package com.cinemasub.browser.translation

import com.cinemasub.browser.model.TranslationEngine
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean

class ArabicTranslator {

    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.ARABIC)
        .build()

    private val mlKitTranslator: Translator = Translation.getClient(options)
    private val isOfflineReady = AtomicBoolean(false)

    // LRU cache keyed by "ENGINE|text"
    private val cache: MutableMap<String, String> = Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(320, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
                return size > 300
            }
        }
    )

    suspend fun ensureModelDownloaded() {
        if (isOfflineReady.get()) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            mlKitTranslator.downloadModelIfNeeded(conditions).await()
            isOfflineReady.set(true)
        }
    }

    suspend fun translateToArabic(sourceText: String): String {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty()) return ""
        if (isAlreadyArabic(cleaned)) return cleaned

        val config = TranslationSettingsStore.currentConfig
        val cacheKey = "${config.engine.name}|$cleaned"
        cache[cacheKey]?.let { return it }

        // 1. Try Selected AI Engine (Gemini or Groq) if API key is provided
        val aiResult: String? = when (config.engine) {
            TranslationEngine.GEMINI_AI -> {
                if (config.geminiApiKey.isNotBlank()) {
                    translateViaGemini(cleaned, config.geminiApiKey.trim())
                } else null
            }
            TranslationEngine.GROQ_AI -> {
                if (config.groqApiKey.isNotBlank()) {
                    translateViaGroq(cleaned, config.groqApiKey.trim())
                } else null
            }
            TranslationEngine.GOOGLE_FREE -> null
        }

        if (!aiResult.isNullOrBlank()) {
            cache[cacheKey] = aiResult
            return aiResult
        }

        // 2. Automatic Fallback: Google Translate Free Online (0 cost, unlimited)
        val onlineResult = translateViaGoogleFree(cleaned)
        if (!onlineResult.isNullOrBlank()) {
            cache[cacheKey] = onlineResult
            return onlineResult
        }

        // 3. Offline Fallback: ML Kit
        if (!isOfflineReady.get()) ensureModelDownloaded()
        val offlineResult = runCatching {
            mlKitTranslator.translate(cleaned).await()
        }.getOrDefault("")

        if (offlineResult.isNotBlank()) {
            cache[cacheKey] = offlineResult
        }
        return offlineResult
    }

    private suspend fun translateViaGemini(text: String, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"
                )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2500
                    readTimeout = 3000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }

                val prompt =
                    "Translate this video subtitle into natural, idiomatic Arabic movie-subtitle style. " +
                        "Output ONLY the Arabic translation with no quotes or notes:\n$text"

                val payload = JSONObject().apply {
                    put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", prompt))
                            )
                        )
                    )
                    put(
                        "generationConfig",
                        JSONObject()
                            .put("temperature", 0.2)
                            .put("maxOutputTokens", 120)
                    )
                }

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    conn.disconnect()
                    return@runCatching null
                }

                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()

                val root = JSONObject(body)
                val candidates = root.optJSONArray("candidates") ?: return@runCatching null
                val parts = candidates.getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                parts.getJSONObject(0).optString("text", "").trim().trim('"')
            }.getOrNull()
        }

    private suspend fun translateViaGroq(text: String, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = URL("https://api.groq.com/openai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2000
                    readTimeout = 2500
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }

                val messages = JSONArray()
                    .put(
                        JSONObject()
                            .put("role", "system")
                            .put(
                                "content",
                                "Translate video subtitles into natural Arabic movie-subtitle style. Output ONLY the Arabic translation."
                            )
                    )
                    .put(
                        JSONObject()
                            .put("role", "user")
                            .put("content", text)
                    )

                val payload = JSONObject()
                    .put("model", "llama-3.1-8b-instant")
                    .put("temperature", 0.2)
                    .put("max_tokens", 120)
                    .put("messages", messages)

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    conn.disconnect()
                    return@runCatching null
                }

                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()

                val root = JSONObject(body)
                val choices = root.optJSONArray("choices") ?: return@runCatching null
                choices.getJSONObject(0)
                    .getJSONObject("message")
                    .optString("content", "")
                    .trim()
                    .trim('"')
            }.getOrNull()
        }

    private fun isAlreadyArabic(text: String): Boolean {
        var arabicCount = 0
        var letterCount = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letterCount++
                if (ch in '\u0600'..'\u06FF') arabicCount++
            }
        }
        return letterCount > 0 && (arabicCount * 2 > letterCount)
    }

    private suspend fun translateViaGoogleFree(text: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr =
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1500
                readTimeout = 1500
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONArray(body)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.getJSONArray(i).optString(0, "")
                sb.append(part)
            }
            sb.toString().trim()
        }.getOrNull()
    }

    fun close() {
        mlKitTranslator.close()
    }
}
