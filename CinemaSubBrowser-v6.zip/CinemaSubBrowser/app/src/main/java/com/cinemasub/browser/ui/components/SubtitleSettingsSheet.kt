package com.cinemasub.browser.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.SubtitleBgOpacity
import com.cinemasub.browser.model.SubtitleFontSize
import com.cinemasub.browser.model.SubtitleStyleConfig
import com.cinemasub.browser.model.SubtitleTextColor
import com.cinemasub.browser.model.TranslationEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubtitleSettingsSheet(
    styleConfig: SubtitleStyleConfig,
    aiConfig: AiTranslationConfig,
    onEngineChange: (TranslationEngine) -> Unit,
    onGeminiKeyChange: (String) -> Unit,
    onGroqKeyChange: (String) -> Unit,
    onFontSizeChange: (SubtitleFontSize) -> Unit,
    onTextColorChange: (SubtitleTextColor) -> Unit,
    onBgOpacityChange: (SubtitleBgOpacity) -> Unit,
    onVerticalBiasChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "إعدادات الترجمة والذكاء الاصطناعي",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // AI Engine Selector
                Text("محرك الترجمة", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TranslationEngine.entries.forEach { engine ->
                        FilterChip(
                            selected = aiConfig.engine == engine,
                            onClick = { onEngineChange(engine) },
                            label = { Text(engine.labelAr, fontSize = 12.sp) }
                        )
                    }
                }

                if (aiConfig.engine == TranslationEngine.GEMINI_AI) {
                    OutlinedTextField(
                        value = aiConfig.geminiApiKey,
                        onValueChange = onGeminiKeyChange,
                        label = { Text("مفتاح Gemini API المجاني") },
                        placeholder = { Text("AIzaSy...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "يتم حفظ المفتاح تلقائياً. في حال انتهاء الحد اليومي، يعود التطبيق لترجمة جوجل تلقائياً.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else if (aiConfig.engine == TranslationEngine.GROQ_AI) {
                    OutlinedTextField(
                        value = aiConfig.groqApiKey,
                        onValueChange = onGroqKeyChange,
                        label = { Text("مفتاح Groq API المجاني") },
                        placeholder = { Text("gsk_...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "سريع جداً لترجمة الفيديوهات. في حال انتهاء الحد اليومي، يعود لترجمة جوجل تلقائياً.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                // Live Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1F2937)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .background(styleConfig.bgOpacity.color, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "معاينة الترجمة العربية بأسلوب سينمائي",
                            style = TextStyle(
                                color = styleConfig.textColor.color,
                                fontSize = styleConfig.fontSize.sp.sp,
                                fontWeight = FontWeight.Bold,
                                shadow = Shadow(Color.Black, Offset(2f, 2f), 5f)
                            )
                        )
                    }
                }

                Text("حجم الخط", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SubtitleFontSize.entries.forEach { size ->
                        FilterChip(
                            selected = styleConfig.fontSize == size,
                            onClick = { onFontSizeChange(size) },
                            label = { Text(size.labelAr) }
                        )
                    }
                }

                Text("لون النص", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    SubtitleTextColor.entries.forEach { option ->
                        val selected = styleConfig.textColor == option
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onTextColorChange(option) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(option.color)
                            )
                            Text(option.labelAr)
                        }
                    }
                }

                Text("خلفية الترجمة", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SubtitleBgOpacity.entries.forEach { bg ->
                        FilterChip(
                            selected = styleConfig.bgOpacity == bg,
                            onClick = { onBgOpacityChange(bg) },
                            label = { Text(bg.labelAr) }
                        )
                    }
                }

                Text(
                    text = "الموضع العمودي (${(styleConfig.verticalBias * 100).toInt()}%)",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = styleConfig.verticalBias,
                    onValueChange = onVerticalBiasChange,
                    valueRange = 0.1f..0.9f
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
