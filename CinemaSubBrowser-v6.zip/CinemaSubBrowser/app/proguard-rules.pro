-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keep class com.google.mlkit.** { *; }
-keepclassmembers class com.cinemasub.browser.browser.CaptionJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
